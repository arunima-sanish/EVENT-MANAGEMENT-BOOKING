// Function to show user login container and hide admin login container
function userLogin() {
    var userLoginForm = document.getElementById("userlogincontainerid");
    var adminLoginForm = document.getElementById("adminlogincontainerid");
    var signupForm = document.getElementById("signupcontainerid");

    // Show user login form
    userLoginForm.style.display = "block";
    // Hide admin login form
    adminLoginForm.style.display = "none";
    // Hide signup form
    signupForm.style.display = "none";
}

// Function to show the signup container
function showSignupContainer() {
    var signupForm = document.getElementById("signupcontainerid");
    var userLoginForm = document.getElementById("userlogincontainerid");

    // Hide user login form
    userLoginForm.style.display = "none";
    // Show signup form
    signupForm.style.display = "block";
    adminLoginForm.style.display = "none";
}

// Attach event listener to the Sign Up button to show the signup container
document.getElementById("user-signupbtn").addEventListener("click", function () {
    showSignupContainer();
});

// Rest of your existing code...


// Function to toggle admin login container visibility
function adminLogin() {
    var adminLoginForm = document.getElementById("adminlogincontainerid");
    // Show admin login form
    adminLoginForm.style.display = "block";
     // Show user login form
    userLoginForm.style.display = "none";
    // Hide admin login form
   
    // Hide signup form
    signupForm.style.display = "none";
}

// Function to handle user login
function handleUserLogin() {
    let username = document.getElementById("user-username").value;
    let password = document.getElementById("user-password").value;
    // Check if username or password is empty
    if (username.trim() === "" || password.trim() === "") {
        alert("Please enter both username and password");
        return;
    }

    // Perform login authentication (you can replace this with your actual authentication logic)
    // For demonstration purposes, we'll just show an alert message
    alert("User Login successful!");
    // Redirect to the user dashboard or another page
    // window.location.href = "user_dashboard.html";
}

// Function to handle admin login
// Array to store admin credentials
const admins = [
    { username: "admin1", password: "admin123" },
    { username: "admin2", password: "admin456" }
];

// Function to handle admin login
function handleAdminLogin() {
    let username = document.getElementById("admin-username").value;
    let password = document.getElementById("admin-password").value;

    // Check if username or password is empty
    if (username.trim() === "" || password.trim() === "") {
        alert("Please enter both username and password");
        return;
    }

    // Check if the admin credentials are correct
    let isAdmin = false;
    for (let admin of admins) {
        if (admin.username === username && admin.password === password) {
            isAdmin = true;
            break;
        }
    }

    // If admin credentials are correct, show success message
    if (isAdmin) {
        alert("Admin Login successful!");
        // Redirect to the admin dashboard or another page (optional)
        // window.location.href = "admin_dashboard.html";
    } else {
        alert("Invalid username or password");
    }
}

// Attach event listeners to the user sign-in and sign-up buttons
document.getElementById("user-signinbtn").addEventListener("click", function () {
    handleUserLogin();
});

document.getElementById("user-signupbtn").addEventListener("click", function () {
    // Show the sign-up form
    document.getElementById("signupcontainerid").style.display = "block";
});

// Attach event listener to the admin sign-in button
document.getElementById("admin-signinbtn").addEventListener("click", function () {
    handleAdminLogin();
});

// Attach event listener to the admin login button to show the admin login form
document.getElementById("adminloginbtn").addEventListener("click", function () {
    adminLogin();
});

// Function to handle user sign up
function handleUserSignup() {
    let username = document.getElementById("signup-username").value;
    let password = document.getElementById("signup-password").value;
    // Check if username or password is empty
    if (username.trim() === "" || password.trim() === "") {
        alert("Please enter both username and password");
        return;
    }

    // Perform sign up process (you can replace this with your actual sign up logic)
    // For demonstration purposes, we'll just show an alert message
    alert("User Sign Up successful!");
}

// Attach event listener to the Sign Up button
document.getElementById("signupbtn").addEventListener("click", function () {
    handleUserSignup();
});

// Call userLogin function to show user login form by default
userLogin();





// Array to store registered users
const registeredUsers = [];

// Function to handle user sign up
function handleUserSignup() {
    let username = document.getElementById("signup-username").value;
    let password = document.getElementById("signup-password").value;
    // Check if username or password is empty
    if (username.trim() === "" || password.trim() === "") {
        alert("Please enter both username and password");
        return;
    }

    // Check if the username already exists
    const existingUser = registeredUsers.find(user => user.username === username);
    if (existingUser) {
        alert("Username already exists. Please choose another one.");
        return;
    }

    // Add new user to the array
    registeredUsers.push({ username, password });
    alert("User Sign Up successful!");
}

// Function to handle user login
function handleUserLogin() {
    let username = document.getElementById("user-username").value;
    let password = document.getElementById("user-password").value;
    // Check if username or password is empty
    if (username.trim() === "" || password.trim() === "") {
        alert("Please enter both username and password");
        return;
    }

    // Find user in the array
    const user = registeredUsers.find(user => user.username === username && user.password === password);
    if (user) {
        alert("User Login successful!");
        // Redirect or perform any action after successful login
        // For now, let's just reset the login form
        document.getElementById("user-login-form").reset();
    } else {
        alert("Invalid username or password");
    }
}

// Attach event listener to the Sign Up button
document.getElementById("signupbtn").addEventListener("click", function () {
    handleUserSignup();
});

// Attach event listener to the Sign In button
document.getElementById("user-signinbtn").addEventListener("click", function () {
    handleUserLogin();
});
//aboutus
function navigateToAboutUs() {
    const contactForm = document.getElementById('about_container');
    contactForm.scrollIntoView({ behavior: 'smooth' });
  }
