function openAdminPage() 
{
    window.open("adminpage.html", "_blank");
 }
 
 function openaddevnt() 
{
    window.open("addevent.html", "_blank");
 }
 function openupdate() 
{
    window.open("update.html", "_blank");
 }

