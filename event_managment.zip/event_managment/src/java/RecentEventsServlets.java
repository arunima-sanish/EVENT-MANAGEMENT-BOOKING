import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/setRecentlyAddedEventsCookie")
public class RecentEventsServlets extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set cookie with maxAge
        Cookie cookie = new Cookie("showRecentEvents", "true");
        cookie.setMaxAge(10); // 10 seconds
        response.addCookie(cookie);

        // Fetch the latest added event from the database
        String latestEvent = fetchLatestEventFromDatabase();

        // Display the latest event
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Recently Added Event</title>");
        out.println("<style>");
        out.println("#latestEvent { font-size: 25px; color: green; margin-top: 20px;  }");
        out.println("body{ background-image: url('ad1.jpg');}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Recently Added Event</h1>");
        out.println("<p id='latestEvent'>" + latestEvent + "</p>");
        out.println("</body>");
        out.println("</html>");

        // Include JavaScript to remove the event after 10 seconds
        out.println("<script>");
        out.println("setTimeout(function() { "
                    + "document.getElementById('latestEvent').remove(); "
                    + "alert('Cookie expired!'); }, 10000);");        
        out.println("</script>");
    }

    private String fetchLatestEventFromDatabase() {
        String latestEvent = null;
        // Database connection parameters
        String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost:3306/event";
        String USER = "root";
        String PASS = "";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            String sql = "SELECT event_name FROM addeventtable1 ORDER BY event_id DESC LIMIT 1";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                latestEvent = rs.getString("event_name");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return latestEvent;
    }
}
