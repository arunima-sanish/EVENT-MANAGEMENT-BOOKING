import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/getSessionDetails")
public class SessionDetailsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Get the current session or create a new one if it doesn't exist
        HttpSession session = request.getSession();

        // Get session details
        String sessionId = session.getId();
        String username = (String) session.getAttribute("user-username");
        Date creationTime = new Date(session.getCreationTime());
        Date lastAccessedTime = new Date(session.getLastAccessedTime());

        // Print session details with styling
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Session Details</title>");
            out.println("<style>");
            out.println(".session-details {");
            out.println("  border: 1px solid #ccc;");
            out.println("  padding: 10px;");
            out.println("  margin-top: 50px;");
            out.println("  margin: 10px;");
            out.println("  background-color: white;");
            out.println("}");
             out.println("h1 {");
             out.println("  margin-top: 70px;");
             out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Welcome, " + username + "</h1>");
            out.println("<h1>Session Details</h1>");
            out.println("<div class='session-details'>");
            out.println("<p><strong>Session ID:</strong> " + sessionId + "</p>");
            out.println("<p><strong>Username:</strong> " + username + "</p>");
            out.println("<p><strong>Session Creation Time:</strong> " + creationTime + "</p>");
            out.println("<p><strong>Session Last Accessed Time:</strong> " + lastAccessedTime + "</p>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
