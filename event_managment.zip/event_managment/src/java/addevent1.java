/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



/**
 *
 * @author dell
 */
@WebServlet(urlPatterns = {"/addevent1"})
public class addevent1 extends HttpServlet {

   private static final long serialVersionUID = 1L;
protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Database connection parameters
        String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost:3306/event";
        String USER = "root";
        String PASS = "";

        Connection conn = null;
        PreparedStatement pstmt = null;

        // Get form data
        String eventName = request.getParameter("eventName");
        String eventDate = request.getParameter("eventType");
        String eventDescription = request.getParameter("eventDescription");
        String cost = request.getParameter("cost");


        try {
            Class.forName(JDBC_DRIVER);

            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            String sql = "INSERT INTO addeventtable1 (event_name, event_type, event_description,cost) VALUES (?, ?, ?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, eventName);
            pstmt.setString(2, eventDate);
            pstmt.setString(3, eventDescription);
            pstmt.setString(4, cost);


            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                // Use AJAX to show an alert message
                out.println("<script>");
                out.println("alert('Event added successfully!');");
                out.println("</script>");
            } else {
                out.println("<h2>Failed to add event!</h2>");
            }
        } catch (SQLException se) {
            se.printStackTrace();
            out.println("<h2>SQL Error: " + se.getMessage() + "</h2>");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            try {
                if (pstmt != null)
                    pstmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
}


        
 protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    // Database connection parameters
    String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    String DB_URL = "jdbc:mysql://localhost:3306/event";
    String USER = "root";
    String PASS = "";

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName(JDBC_DRIVER);

        conn = DriverManager.getConnection(DB_URL, USER, PASS);

        String sql = "SELECT * FROM addeventtable1";
        pstmt = conn.prepareStatement(sql);

        rs = pstmt.executeQuery();

        out.println("<html><head><title>Event List</title></head><body>");
        out.println("<h2>Event List</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Event Name</th><th>Event Type</th><th>Event Description</th><th> cost</th></tr>");

        while (rs.next()) {
            String eventName = rs.getString("event_name");
            String eventType = rs.getString("event_type");
            String eventDescription = rs.getString("event_description");
            String cost = rs.getString("cost");


            out.println("<tr><td>" + eventName + "</td><td>" + eventType + "</td><td>" + eventDescription + "</td><td>" + cost + "</td></tr>");
        }

        out.println("</table>");
        out.println("</body></html>");
    } catch (SQLException se) {
        se.printStackTrace();
        out.println("<h2>SQL Error: " + se.getMessage() + "</h2>");
    } catch (Exception e) {
        e.printStackTrace();
        out.println("<h2>Error: " + e.getMessage() + "</h2>");
    } finally {
        try {
            if (rs != null)
                rs.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }
        try {
            if (pstmt != null)
                pstmt.close();
        } catch (SQLException se2) {
        }
        try {
            if (conn != null)
                conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }
    }
}

}




