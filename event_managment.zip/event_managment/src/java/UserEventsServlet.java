import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class UserEventsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set up the connection to your database
        String url = "jdbc:mysql://localhost:3306/event";
        String user = "root";
        String password = "";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Create a connection to the database
            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                // Create a PreparedStatement to query the last created event
                String sql = "SELECT * FROM bookdata ORDER BY bookid DESC LIMIT 1";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    System.out.println("Executing SQL query: " + sql); // Log the SQL query
                    ResultSet rs = stmt.executeQuery();

                    // Generate HTML content to display the last created event
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.println("<html><head><title>Last Created Event</title></head><body>");
                    out.println("<h1>Last Created Event</h1>");
                    out.println("<ul>");
                    if (rs.next()) {
                        String eventName = rs.getString("name"); // Assuming the column name is "name"
                        out.println("<li>" + eventName + "</li>");
                        // You can display other event details here
                    } else {
                        out.println("<li>No events found</li>");
                    }
                    out.println("</ul>");
                    out.println("</body></html>");
                }
            }
        } catch (ClassNotFoundException e) {
            // Handle the class not found exception
            e.printStackTrace();
        } catch (SQLException e) {
            // Handle any errors that may occur
            e.printStackTrace();
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><head><title>Error</title></head><body>");
            out.println("<h1>An error occurred. Please try again later.</h1>");
            out.println("</body></html>");
        }
    }
}
