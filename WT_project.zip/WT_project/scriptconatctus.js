function scrollToContact() {
    const contactForm = document.getElementById('contact-form');
    contactForm.scrollIntoView({ behavior: 'smooth' });
  }

  function navigateToEventRegister() {
    window.location.href = 'eventregister.html'; // Change 'eventregister.html' to the actual URL of your event register page
  }