const wrapper = document.querySelector('.wrapper');
const loginlink = document.querySelector('.loginlink');
const loginreister = document.querySelector('.loginreister');
const btn = document.querySelector('.navbtn');
const iconClose = document.querySelector('.iconclose');

loginreister.addEventListener('click', () => {
    wrapper.classList.add('active');
});

loginlink.addEventListener('click', () => {
    wrapper.classList.remove('active');
});

btn.addEventListener('click', () => {
  
        wrapper.classList.add('active-popup');
    
});

iconClose.addEventListener('click', () => {
    wrapper.classList.remove('active-popup');
});

function navigateToEventRegister() {
    window.location.href = 'events.html';
}
