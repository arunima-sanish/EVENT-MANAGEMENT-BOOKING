// Array to store user information
let users = [];

// Get the login and signup containers
let loginContainer = document.getElementById("logincontainerid");
let signupContainer = document.getElementById("signupcontainerid");

// Function to show login container and hide signup container
function login() {
    loginContainer.style.display = "block";
    signupContainer.style.display = "none";
    // Clear the form fields
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
}

// Function to show signup container and hide login container
function signup() {
    signupContainer.style.display = "block";
    loginContainer.style.display = "none";
    // Clear the form fields
    document.getElementById("signup-username").value = "";
    document.getElementById("signup-password").value = "";
    document.getElementById("signup-email").value = "";
}

// Function to handle signup
function handleSignup() {
    let username = document.getElementById("signup-username").value;
    let password = document.getElementById("signup-password").value;
    let email = document.getElementById("signup-email").value;

    // Check if username already exists
    for (let i = 0; i < users.length; i++) {
        if (users[i].username === username) {
            alert("Username already exists");
            return;
        }
    }

    // Store user information in the array
    users.push({ username: username, password: password, email: email });
    alert("Signup successful");
    // Switch to login form after signup
    login();
}

// Function to handle login
function handleLogin() {
    let email = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    // Check if email or password is empty
    if (email === "" || password === "") {
        window.location.href = "events.html";
        alert("Please enter both email and password");
        return;}

    // Check if there is a user with the provided email and password
    let user = users.find(user => user.email === email && user.password === password);
    if (user) {
        alert("Login successful!");
        // Reset the form
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
    
    } 
    // else {
    //     alert("Invalid email or password");
    // }
}


// Attach event listeners to the login and signup buttons
document.getElementById("signinbtn").addEventListener("click", handleLogin);
document.getElementById("registerbtn").addEventListener("click", handleSignup);
//scroll to about us
function navigateToAboutUs() {
    const contactForm = document.getElementById('about_container');
    contactForm.scrollIntoView({ behavior: 'smooth' });
  }