function navigateToGallery() {
    window.location.href = 'gallery.html'; // Change 'eventregister.html' to the actual URL of your event register page
  }

   
/*slideshow*/
 let slideIndex = 0;

    showSlide();

    function showSlide() {
        let slides = document.getElementsByClassName("carousel-img");
        let dots = document.getElementsByClassName("dot");

        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
            dots[i].className = dots[i].className.replace(" active", "");
        }

        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1;
        }

        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";

        setTimeout(showSlide, 2000); // Change image every 2 seconds
    }

    function changeSlide(n) {
        slideIndex += n;
        showSlide();
    }

    function currentSlide(n) {
        slideIndex = n;
        showSlide();
    }
  //  separateimage 
  document.querySelectorAll('.show-pictures').forEach(function(link) {
    link.addEventListener('click', function(event) {
      // Hide all images
      document.querySelectorAll('.images').forEach(function(images) {
        images.style.display = 'none';
      });
      
      // Show the images corresponding to the clicked link
      var targetId = link.getAttribute('data-target');
      document.getElementById(targetId).style.display = 'block';
      
      // Prevent the default link behavior
      event.preventDefault();
    });
  });
  