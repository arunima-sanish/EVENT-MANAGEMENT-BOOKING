<?php

// Define an associative array with information about the team members
$team_members = array(
    array(
        "name" => "John Doe",
        "position" => "CEO",
        "bio" => "John is the visionary behind our company...",
        "img" => "icon.png"
    ),
    array(
        "name" => "Jane Smith",
        "position" => "CTO",
        "bio" => "Jane oversees the technical aspects of our projects...",
        "img" => "icon.png"
    ),
    array(
        "name" => "David Johnson",
        "position" => "COO",
        "bio" => "David manages the day-to-day operations...",
        "img" => "icon.png"
    )
);

// Function to print team member details with string operations
function print_team_member($member) {
    $full_name = strtoupper($member['name']); // Convert name to uppercase
    $bio_snippet = substr($member['bio'], 0, 30) . "..."; // Get a snippet of the bio
    $position_upper = ucfirst($member['position']); // Capitalize the first letter of the position

    echo "<h2>$full_name</h2>";
    echo "<p><strong>$position_upper</strong></p>";
    echo "<p>$bio_snippet</p>";
    echo "<img src='{$member['img']}' alt='{$member['name']}' width='150'><br><br>";
}

// Check if the team members array is not empty
if (!empty($team_members)) {
    // Loop through each team member
    foreach ($team_members as $member) 
    {
        print_team_member($member);
    }
} 
else 
{
    // If team members array is empty, display a message
    echo "<p>Sorry, no team members available at the moment.</p>";
}

// Adding a date
echo "<p>Today's date is: " . date('Y-m-d') . "</p>";

// Adding dynamic content based on time of the day
$current_hour = date('H');

if ($current_hour < 12) {
    echo "<p>Good morning!</p>";
} elseif ($current_hour < 18) {
    echo "<p>Good afternoon!</p>";
} else {
    echo "<p>Good evening!</p>";
}

// Displaying a general message
echo "<p>Welcome to our company website. We are dedicated to delivering the best service.</p>";

// About section
$about_title = "About Us";
$about_content = "We are a team of dedicated professionals committed to providing exceptional service and innovative solutions.";
$about_highlight = "Our mission is to exceed client expectations with our comprehensive services and expert team.";

echo "<h1>$about_title</h1>";
echo "<p>" . strtoupper($about_content) . "</p>"; // Convert about content to uppercase
echo "<p><strong>" . ucfirst(strtolower($about_highlight)) . "</strong></p>"; // Proper case for about highlight

// Additional information
$company_motto = "Your success is our priority.";
echo "<p>Motto: " . strtoupper($company_motto) . "</p>"; // Convert motto to uppercase

?>
