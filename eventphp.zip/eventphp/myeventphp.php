<!DOCTYPE html>
<html>
<head>
  <title>My Events</title>
</head>
<body>
  <h2>Enter Your Name</h2>
  <form method="post">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" placeholder="Enter your name">
    <input type="submit" value="Submit">
  </form>
<?php
// Assuming you have a MySQL database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the URL parameter
if (isset($_GET['username'])) {
    $username = $_GET['username'];

    // Prepare a SQL query to fetch events for the given username
    $sql = "SELECT * FROM bookdata WHERE name = '$username'";

    // Execute the query
    $result = $conn->query($sql);

    // Check if any events were found
    if ($result->num_rows > 0) {
        // Output the events in a formatted way
        while ($row = $result->fetch_assoc()) {
            echo "<div class='event-item'>";
            echo "<div class='event-item-content'>";
            echo "<h3>" . $row['event_name'] . "</h3>";
            echo "<p>" . $row['event_description'] . "</p>";
            echo "</div>";
            echo "</div>";
        }
    } else {
        echo "No events found for username: " . $username;
    }
} else {
    echo "Username parameter not provided";
}

$conn->close();
?>

</body>
</html>
