<?php
       
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hostel";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$resid = $_POST['resid'];
$respassword = $_POST['respassword'];

// Insert data into login table
$sql = "INSERT INTO login (resid, respassword) VALUES ('$resid', '$respassword')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
        
   
