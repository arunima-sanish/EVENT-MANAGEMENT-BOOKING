<?php
// Assuming you have a MySQL database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert new event into the bookdata table
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['eventname']) && isset($_POST['eventdate']) && isset($_POST['venue']) && isset($_POST['eventtype']) && isset($_POST['headcount'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $eventName = $_POST['eventname'];
    $eventDate = $_POST['eventdate'];
    $venue = $_POST['venue'];
    $eventType = $_POST['eventtype'];
    $headCount = $_POST['headcount'];

    $sql = "INSERT INTO bookdata (name, email, phone_no, event_name, event_date, venue, event_type, head_count)
            VALUES ('$name', '$email', '$phone', '$eventName', '$eventDate', '$venue', '$eventType', '$headCount')";

    if ($conn->query($sql) === TRUE) {
        echo "New event added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
