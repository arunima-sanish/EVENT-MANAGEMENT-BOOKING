<?php
// Database connection parameters
$host = "localhost";
$dbname = "event"; // Change to your database name
$username = "root"; // Change to your database username
$password = ""; // Change to your database password

try {
    // Create connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $eventName = $_POST['eventname'];
    $eventDate = $_POST['eventdate'];
    $venueLocation = $_POST['venue'];
    $eventType = $_POST['eventtype'];
    $headCount = $_POST['headcount'];

    // Get the username to update
    $usernameToUpdate = $_POST['name']; // Assuming you have a form field for the username

    // Prepare SQL statement for update
    $sql = "UPDATE bookdata 
            SET name = :name, email = :email, phone_no = :phone, event_name = :eventName, event_date = :eventDate, 
                venue = :venueLocation, event_type = :eventType, head_count = :headCount
            WHERE name = :usernameToUpdate";

    // Prepare and execute the statement
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':eventName', $eventName);
    $stmt->bindParam(':eventDate', $eventDate);
    $stmt->bindParam(':venueLocation', $venueLocation);
    $stmt->bindParam(':eventType', $eventType);
    $stmt->bindParam(':headCount', $headCount);
    $stmt->bindParam(':usernameToUpdate', $usernameToUpdate);
    $stmt->execute();

    echo "Event updated successfully!";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
// Close the connection
$conn = null;
?>
