<?php
// Database connection parameters
$host = "localhost";
$dbname = "event"; // Change to your database name
$username = "root"; // Change to your database username
$password = ""; // Change to your database password

try {
    // Create connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get the event name and customer's name of the record to delete
    $eventName = $_POST['eventname'];
    $name = $_POST['name'];

    // Prepare SQL statement for deletion
    $sql = "DELETE FROM bookdata WHERE event_name = :eventName AND name = :name";

    // Prepare and execute the statement
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':eventName', $eventName);
    $stmt->bindParam(':name', $name);
    $stmt->execute();

    echo "Booking deleted successfully!";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
// Close the connection
$conn = null;
?>
